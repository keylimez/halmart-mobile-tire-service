# Halmart Mobile Tire Service Website

This is a static HTML/CSS/JavaScript website, ready to publish with GitHub Pages.

## Publish it with GitHub Pages

1. Sign in to GitHub and create a **new public repository** named `halmart-mobile-tire-service`.
2. Upload `index.html` to the top level of the repository (not inside another folder).
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and the `/ (root)` folder, then click **Save**.
6. Wait a few minutes. GitHub will show the public website URL in the Pages section.

The URL will usually look like:
`https://YOUR-GITHUB-USERNAME.github.io/halmart-mobile-tire-service/`

## Important checks before sharing with customers

Please confirm the business details in `index.html` are accurate:
- Phone: (561) 888-1230
- Email: hallmark33407@gmail.com
- Address: 1501 N Tamarind Ave, West Palm Beach, FL 33407
- Hours: daily, 6:30 AM–10:00 PM
- The page currently displays a 4.9/5 customer rating.
- The mobile tire installation service card contains a note asking the owner to confirm that service.
- Nearby-city service-area entries are marked as placeholders.

The request form currently opens the visitor's email application with the request filled in. It does not submit to a website database or send automatically. Customers need a configured email app to send it. A hosted form service or backend is needed for a true online submission form.

## Updating the website

Edit `index.html`, then upload the changed file to the same location in the GitHub repository. GitHub Pages will publish the update automatically after deployment.
